package com.cognizant.controllers;

import com.cognizant.dtos.IncidentTypeDTO;
import com.cognizant.services.IncidentTypeService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/incidents/types")
public class IncidentTypeController {

    private  final IncidentTypeService incidentTypeService;

    public IncidentTypeController(IncidentTypeService incidentTypeService) {
        this.incidentTypeService = incidentTypeService;
    }

    @GetMapping
    public List<IncidentTypeDTO> getAllIncidentTypes(){
        return incidentTypeService.getAllIncidentTypeDTO();
    }
}
