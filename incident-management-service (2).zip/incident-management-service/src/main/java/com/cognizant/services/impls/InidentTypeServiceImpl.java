package com.cognizant.services.impls;

import com.cognizant.dtos.IncidentTypeDTO;
import com.cognizant.entities.IncidentTypes;
import com.cognizant.repositories.IncidentTypeRepository;
import com.cognizant.services.IncidentTypeService;
import com.cognizant.utilities.IncidentTypeMapper;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class InidentTypeServiceImpl implements IncidentTypeService {

    //Autowired is a field injection , it is not recommended to use
    //field injection instead use constructor injection

    private final IncidentTypeRepository incidentTypeRepository;

    private final IncidentTypeMapper incidentTypeMapper;

    public InidentTypeServiceImpl(IncidentTypeRepository incidentTypeRepository, IncidentTypeMapper incidentTypeMapper) {
        this.incidentTypeRepository = incidentTypeRepository;
        this.incidentTypeMapper = incidentTypeMapper;
    }

    @Override
    public List<IncidentTypeDTO> getAllIncidentTypeDTO() {

        List<IncidentTypes> incidentTypesList = incidentTypeRepository.findAll();

        List<IncidentTypeDTO> incidentTypeDTOList = new ArrayList<>();
        for(IncidentTypes it : incidentTypesList){
            IncidentTypeDTO incidentTypeDTO = incidentTypeMapper.toIncidentTypeDTO(it);
            incidentTypeDTOList.add(incidentTypeDTO);
        }

        return incidentTypeDTOList;
    }
}
