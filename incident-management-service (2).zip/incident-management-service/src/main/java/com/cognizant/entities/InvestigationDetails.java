package com.cognizant.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import java.time.LocalDate;

@Entity
@Table(name = "Investigation_Details")
public class InvestigationDetails {

    @Id
    @Column(name = "Investigation_Details_Id")
    private int investigationDetailsId;

    @Column(name = "Findings")
    private String findings;

    @Column(name = "Suggestions")
    private String suggestions;

    @Column(name = "Investigation_Date")
    private LocalDate investigationDate;
}
