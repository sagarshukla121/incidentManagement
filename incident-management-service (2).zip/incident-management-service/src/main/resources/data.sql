insert into Incident_Types values
(20001, 1, 3),
(20002, 2, 7),
(20003, 3, 10),
(20004, 4, 2);