package com.cognizant.utilities.test;

import com.cognizant.dtos.IncidentTypeDTO;
import com.cognizant.entities.IncidentTypes;
import com.cognizant.utilities.IncidentTypeMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest
class IncidentTypeMapperTest {

    private IncidentTypeMapper incidentTypeMapper;

    @BeforeEach
    void setUp() {
        incidentTypeMapper = new IncidentTypeMapper();
    }

    @Test
    void should_map_incidentType_to_IncidentType(){
        IncidentTypes incidentTypes = new IncidentTypes();
        incidentTypes.setIncidentTypeId(1);
        incidentTypes.setType(2);
        incidentTypes.setExpectedSLAInDays(10);

        IncidentTypeDTO incidentTypeDTO = incidentTypeMapper.toIncidentTypeDTO(incidentTypes);

        assertEquals(incidentTypeDTO.getIncidentTypeId(), incidentTypes.getIncidentTypeId());
        assertEquals(incidentTypeDTO.getType(), incidentTypes.getType());
        assertEquals(incidentTypeDTO.getExpectedSLAInDays(), incidentTypes.getExpectedSLAInDays());
    }

    @Test
    void incidentType_should_not_be_null(){
        NullPointerException exp = assertThrows(NullPointerException.class,
                () -> incidentTypeMapper.toIncidentTypeDTO(null));
        assertEquals("Incident Type Should Not Be Null", exp.getMessage());
    }
}